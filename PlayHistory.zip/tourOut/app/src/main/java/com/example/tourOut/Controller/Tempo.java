package com.example.tourOut.Controller;

public class Tempo {
    public final int segundo = 1000, minuto = 60 * segundo, hora = 60 * minuto;
}
